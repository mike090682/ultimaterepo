import os, xbmc, xbmcaddon
import binascii
#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = '[COLOR yellow][COLOR blue][B]Ultimate Wizard[/B][COLOR yellow][/COLOR]'
EXCLUDES       = [ADDON_ID, 'repository.ultimate', 'roms', 'My_Builds', 'backupdir']
BUILDFILE      = "https://ia800404.us.archive.org/34/items/ultimatewizard/build.txt"
UPDATECHECK    = 0
APKFILE        = "https://ia800404.us.archive.org/34/items/ultimatewizard/apk17.txt"
YOUTUBETITLE   = 'Ultimate Help Videos' 
YOUTUBEFILE    = 0
ADDONFILE      = 'https://ia600404.us.archive.org/34/items/ultimatewizard/addons.txt'
ADVANCEDFILE   = 'http://'
ROMPACK        = 'https://ia800404.us.archive.org/34/items/ultimatewizard/rom-packs.txt'
EMUAPKS        = 'https://ia800404.us.archive.org/34/items/ultimatewizard/emuapks.txt'
ADDONPACK      = 0
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONMAINT      = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONAPK        = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONADDONS     = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONYOUTUBE    = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONSAVE       = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONTRAKT      = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONREAL       = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONLOGIN      = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONCONTACT    = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
ICONSETTINGS   = 'https://ia800404.us.archive.org/34/items/ultimatewizard/icon.png'
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '~'

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'blue'
COLOR2         = 'yellow'
COLOR3         = 'red'
COLOR4         = 'snow'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR2+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR2+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
THEME6         = '[COLOR '+COLOR3+'][B]%s[/B][/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'No'
# You can add \n to do line breaks
CONTACT        = 'Thank you for choosing Ultimate Wizard. Contact us on facebook at http://facebook.com/groups/ultimatebymike'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'No'
# Url to wizard version
WIZARDFILE     = 'http://'
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'No'
# Addon ID for the repository
REPOID         = 'repository.ultimate'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = binascii.unhexlify('')
# Url to folder zip is located in
REPOZIPURL     = binascii.unhexlify('')
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'Thank you for choosing Ultimate.\r\n\r\nContact us on facebook at http://facebook.com/groups/ultimatebymike'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
# Font size of header
FONTHEADER     = 'Font14'
HEADERMESSAGE  = 'Ultimate Wizard'
# url to image if using Image 424x180
HEADERIMAGE    = ''
# Font for Notification Window
FONTSETTINGS   = 'Font12'
# Background for Notification Window
BACKGROUND     = 'https://ia600404.us.archive.org/34/items/ultimatewizard/UltimateBuildsLogo.png'
############################    #############################